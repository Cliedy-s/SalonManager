﻿namespace Project
{
    partial class _2_MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(_2_MainForm));
            this.phone = new System.Windows.Forms.Panel();
            this.button13 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.msg = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button39 = new System.Windows.Forms.Button();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.ids2 = new System.Windows.Forms.Label();
            this.button41 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label77 = new System.Windows.Forms.Label();
            this.button42 = new System.Windows.Forms.Button();
            this.listView2 = new System.Windows.Forms.ListView();
            this.label22 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.button53 = new System.Windows.Forms.Button();
            this.check = new System.Windows.Forms.CheckBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.joinpanel = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.sellpanel = new System.Windows.Forms.Panel();
            this.listView3 = new System.Windows.Forms.ListView();
            this.panel19 = new System.Windows.Forms.Panel();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.button48 = new System.Windows.Forms.Button();
            this.label90 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.button34 = new System.Windows.Forms.Button();
            this.panel20 = new System.Windows.Forms.Panel();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.button47 = new System.Windows.Forms.Button();
            this.label86 = new System.Windows.Forms.Label();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.label59 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button22 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.listView5 = new System.Windows.Forms.ListView();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label91 = new System.Windows.Forms.Label();
            this.button49 = new System.Windows.Forms.Button();
            this.label66 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button50 = new System.Windows.Forms.Button();
            this.label93 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.listView4 = new System.Windows.Forms.ListView();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label95 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.button52 = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.button28 = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label94 = new System.Windows.Forms.Label();
            this.button51 = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.button29 = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.button43 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.panel23 = new System.Windows.Forms.Panel();
            this.listView6 = new System.Windows.Forms.ListView();
            this.panel24 = new System.Windows.Forms.Panel();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.button37 = new System.Windows.Forms.Button();
            this.panel25 = new System.Windows.Forms.Panel();
            this.ids3 = new System.Windows.Forms.Label();
            this.button46 = new System.Windows.Forms.Button();
            this.label69 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.button40 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label83 = new System.Windows.Forms.Label();
            this.button45 = new System.Windows.Forms.Button();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.button44 = new System.Windows.Forms.Button();
            this.label92 = new System.Windows.Forms.Label();
            this.ids = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.phone.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.joinpanel.SuspendLayout();
            this.panel5.SuspendLayout();
            this.sellpanel.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // phone
            // 
            this.phone.BackColor = System.Drawing.SystemColors.Control;
            this.phone.Controls.Add(this.button13);
            this.phone.Controls.Add(this.button10);
            this.phone.Controls.Add(this.button5);
            this.phone.Controls.Add(this.button6);
            this.phone.Controls.Add(this.button8);
            this.phone.Controls.Add(this.button7);
            this.phone.Location = new System.Drawing.Point(1228, 94);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(176, 495);
            this.phone.TabIndex = 2;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.Control;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("굴림", 9F);
            this.button13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button13.Location = new System.Drawing.Point(0, 54);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(174, 45);
            this.button13.TabIndex = 7;
            this.button13.Text = "회원 등록";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.Control;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("굴림", 9F);
            this.button10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button10.Location = new System.Drawing.Point(0, 258);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(174, 45);
            this.button10.TabIndex = 2;
            this.button10.Text = "문자";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("굴림", 9F);
            this.button5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button5.Location = new System.Drawing.Point(0, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(174, 45);
            this.button5.TabIndex = 1;
            this.button5.Text = "회원 검색";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Control;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("굴림", 9F);
            this.button6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button6.Location = new System.Drawing.Point(0, 105);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(174, 45);
            this.button6.TabIndex = 3;
            this.button6.Text = "회원 수정";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.Control;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("굴림", 9F);
            this.button8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button8.Location = new System.Drawing.Point(0, 207);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(174, 45);
            this.button8.TabIndex = 5;
            this.button8.Text = "개인 매출";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.Control;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("굴림", 9F);
            this.button7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button7.Location = new System.Drawing.Point(0, 156);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(174, 45);
            this.button7.TabIndex = 6;
            this.button7.Text = "회원 제거";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(176, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("굴림", 9F);
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(194, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 80);
            this.button1.TabIndex = 7;
            this.button1.Text = "고객 관리";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Control;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("굴림", 9F);
            this.button2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button2.Location = new System.Drawing.Point(386, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 80);
            this.button2.TabIndex = 8;
            this.button2.Text = "매출";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("굴림", 9F);
            this.button3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button3.Location = new System.Drawing.Point(482, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(103, 80);
            this.button3.TabIndex = 9;
            this.button3.Text = "소모품 관리";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.Enabled = false;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("굴림", 9F);
            this.button4.ForeColor = System.Drawing.Color.DarkGray;
            this.button4.Location = new System.Drawing.Point(591, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 80);
            this.button4.TabIndex = 10;
            this.button4.Text = "시스템 관리";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(0, 0);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(820, 674);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.textBox34);
            this.panel3.Controls.Add(this.label76);
            this.panel3.Controls.Add(this.label75);
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.button12);
            this.panel3.Location = new System.Drawing.Point(821, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(384, 492);
            this.panel3.TabIndex = 49;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(96, 184);
            this.textBox34.MaxLength = 12346;
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(189, 25);
            this.textBox34.TabIndex = 46;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(43, 187);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(37, 15);
            this.label76.TabIndex = 45;
            this.label76.Text = "등급";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label75.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label75.Location = new System.Drawing.Point(43, 416);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(0, 15);
            this.label75.TabIndex = 44;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(229, 142);
            this.textBox4.MaxLength = 4;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(56, 25);
            this.textBox4.TabIndex = 42;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(212, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 15);
            this.label6.TabIndex = 43;
            this.label6.Text = "-";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(154, 142);
            this.textBox3.MaxLength = 4;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(56, 25);
            this.textBox3.TabIndex = 41;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(140, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 15);
            this.label5.TabIndex = 41;
            this.label5.Text = "-";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(96, 142);
            this.textBox2.MaxLength = 3;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(43, 25);
            this.textBox2.TabIndex = 40;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 15);
            this.label4.TabIndex = 39;
            this.label4.Text = "휴대폰";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(44, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(165, 48);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "성별";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(18, 19);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(58, 19);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "남자";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(94, 19);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(58, 19);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "여자";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "고객 이름";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(139, 47);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 25);
            this.textBox1.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 15);
            this.label2.TabIndex = 33;
            this.label2.Text = "회원 검색";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(299, 445);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 31;
            this.button12.Text = "검색";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.Button12_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Control;
            this.panel4.Controls.Add(this.checkBox1);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.textBox5);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.textBox6);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.textBox7);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.dateTimePicker2);
            this.panel4.Controls.Add(this.groupBox2);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.textBox8);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.button9);
            this.panel4.Location = new System.Drawing.Point(821, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(384, 492);
            this.panel4.TabIndex = 50;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(120, 209);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(59, 19);
            this.checkBox1.TabIndex = 49;
            this.checkBox1.Text = "수신";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(42, 211);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(72, 15);
            this.label28.TabIndex = 48;
            this.label28.Text = "수신 거부";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(229, 173);
            this.textBox5.MaxLength = 4;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(56, 25);
            this.textBox5.TabIndex = 44;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(212, 178);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 15);
            this.label7.TabIndex = 43;
            this.label7.Text = "-";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(154, 173);
            this.textBox6.MaxLength = 4;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(56, 25);
            this.textBox6.TabIndex = 42;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(140, 178);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 15);
            this.label8.TabIndex = 41;
            this.label8.Text = "-";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(96, 173);
            this.textBox7.MaxLength = 3;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(43, 25);
            this.textBox7.TabIndex = 40;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(42, 178);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 15);
            this.label9.TabIndex = 39;
            this.label9.Text = "휴대폰";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(96, 135);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 25);
            this.dateTimePicker2.TabIndex = 38;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton3);
            this.groupBox2.Controls.Add(this.radioButton4);
            this.groupBox2.Location = new System.Drawing.Point(45, 80);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(165, 48);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "성별";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(18, 19);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(58, 19);
            this.radioButton3.TabIndex = 1;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "남자";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(94, 19);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(58, 19);
            this.radioButton4.TabIndex = 0;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "여자";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(42, 142);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 15);
            this.label10.TabIndex = 36;
            this.label10.Text = "생일";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(42, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 15);
            this.label11.TabIndex = 0;
            this.label11.Text = "고객 이름";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(139, 47);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 25);
            this.textBox8.TabIndex = 34;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(20, 11);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 15);
            this.label12.TabIndex = 33;
            this.label12.Text = "회원 등록";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(299, 445);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 31;
            this.button9.Text = "등록";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.label96);
            this.panel1.Controls.Add(this.msg);
            this.panel1.Controls.Add(this.ids);
            this.panel1.Controls.Add(this.textBox19);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.button39);
            this.panel1.Controls.Add(this.checkBox4);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.textBox16);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.textBox17);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.textBox18);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.dateTimePicker4);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.textBox9);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Location = new System.Drawing.Point(821, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 492);
            this.panel1.TabIndex = 51;
            // 
            // msg
            // 
            this.msg.AutoSize = true;
            this.msg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.msg.Location = new System.Drawing.Point(43, 325);
            this.msg.Name = "msg";
            this.msg.Size = new System.Drawing.Size(0, 15);
            this.msg.TabIndex = 69;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(91, 90);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 25);
            this.textBox19.TabIndex = 67;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 66;
            this.label3.Text = "이름";
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(299, 46);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(75, 23);
            this.button39.TabIndex = 65;
            this.button39.Text = "선택";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.Button39_Click);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(120, 248);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(59, 19);
            this.checkBox4.TabIndex = 64;
            this.checkBox4.Text = "수신";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(42, 250);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(72, 15);
            this.label24.TabIndex = 63;
            this.label24.Text = "수신 거부";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(229, 215);
            this.textBox16.MaxLength = 4;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(56, 25);
            this.textBox16.TabIndex = 62;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(212, 220);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(15, 15);
            this.label29.TabIndex = 61;
            this.label29.Text = "-";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(154, 215);
            this.textBox17.MaxLength = 4;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(56, 25);
            this.textBox17.TabIndex = 60;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(140, 220);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(15, 15);
            this.label30.TabIndex = 59;
            this.label30.Text = "-";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(96, 215);
            this.textBox18.MaxLength = 3;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(43, 25);
            this.textBox18.TabIndex = 58;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(42, 220);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(52, 15);
            this.label31.TabIndex = 57;
            this.label31.Text = "휴대폰";
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker4.Location = new System.Drawing.Point(96, 177);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(200, 25);
            this.dateTimePicker4.TabIndex = 56;
            this.dateTimePicker4.Value = new System.DateTime(2019, 5, 15, 0, 0, 0, 0);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButton7);
            this.groupBox4.Controls.Add(this.radioButton8);
            this.groupBox4.Location = new System.Drawing.Point(45, 122);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(165, 48);
            this.groupBox4.TabIndex = 55;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "성별";
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(18, 19);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(58, 19);
            this.radioButton7.TabIndex = 1;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "남자";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(94, 19);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(58, 19);
            this.radioButton8.TabIndex = 0;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "여자";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(42, 184);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(37, 15);
            this.label32.TabIndex = 54;
            this.label32.Text = "생일";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(42, 50);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(132, 15);
            this.label33.TabIndex = 51;
            this.label33.Text = "고객을 선택하세요";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(20, 11);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(72, 15);
            this.label34.TabIndex = 52;
            this.label34.Text = "회원 수정";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(219, 279);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 15);
            this.label14.TabIndex = 47;
            this.label14.Text = "Point";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(117, 274);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 25);
            this.textBox9.TabIndex = 46;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(43, 279);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 15);
            this.label13.TabIndex = 45;
            this.label13.Text = "Vip포인트";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(299, 445);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 31;
            this.button11.Text = "수정";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.Button11_Click_1);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.Control;
            this.panel8.Controls.Add(this.ids2);
            this.panel8.Controls.Add(this.button41);
            this.panel8.Controls.Add(this.label18);
            this.panel8.Controls.Add(this.label17);
            this.panel8.Controls.Add(this.label21);
            this.panel8.Controls.Add(this.button14);
            this.panel8.Location = new System.Drawing.Point(821, 4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(384, 492);
            this.panel8.TabIndex = 54;
            // 
            // ids2
            // 
            this.ids2.AutoSize = true;
            this.ids2.Location = new System.Drawing.Point(43, 93);
            this.ids2.Name = "ids2";
            this.ids2.Size = new System.Drawing.Size(0, 15);
            this.ids2.TabIndex = 37;
            this.ids2.Visible = false;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(299, 49);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(75, 23);
            this.button41.TabIndex = 36;
            this.button41.Text = "선택";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.Button41_Click_1);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(125, 50);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(30, 15);
            this.label18.TabIndex = 35;
            this.label18.Text = "0명";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(42, 50);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 15);
            this.label17.TabIndex = 34;
            this.label17.Text = "선택 회원";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(20, 11);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(72, 15);
            this.label21.TabIndex = 33;
            this.label21.Text = "회원 제거";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(299, 445);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 31;
            this.button14.Text = "제거";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.Button14_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.Control;
            this.panel9.Controls.Add(this.label77);
            this.panel9.Controls.Add(this.button42);
            this.panel9.Controls.Add(this.listView2);
            this.panel9.Controls.Add(this.label22);
            this.panel9.Location = new System.Drawing.Point(821, 4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(384, 492);
            this.panel9.TabIndex = 55;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(23, 45);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(147, 15);
            this.label77.TabIndex = 57;
            this.label77.Text = "고객을 선택해주세요";
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(280, 39);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(75, 23);
            this.button42.TabIndex = 56;
            this.button42.Text = "선택";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.Button42_Click);
            // 
            // listView2
            // 
            this.listView2.Location = new System.Drawing.Point(18, 77);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(351, 391);
            this.listView2.TabIndex = 55;
            this.listView2.UseCompatibleStateImageBehavior = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(20, 11);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(72, 15);
            this.label22.TabIndex = 33;
            this.label22.Text = "개인 매출";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.Control;
            this.panel10.Controls.Add(this.label25);
            this.panel10.Controls.Add(this.button53);
            this.panel10.Controls.Add(this.check);
            this.panel10.Controls.Add(this.label27);
            this.panel10.Controls.Add(this.label26);
            this.panel10.Controls.Add(this.button16);
            this.panel10.Controls.Add(this.textBox14);
            this.panel10.Controls.Add(this.label23);
            this.panel10.Controls.Add(this.button17);
            this.panel10.Location = new System.Drawing.Point(821, 4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(384, 492);
            this.panel10.TabIndex = 55;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(27, 445);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(0, 15);
            this.label25.TabIndex = 53;
            this.label25.Visible = false;
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(299, 337);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(75, 23);
            this.button53.TabIndex = 52;
            this.button53.Text = "선택";
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.Button53_Click);
            // 
            // check
            // 
            this.check.AutoSize = true;
            this.check.Checked = true;
            this.check.CheckState = System.Windows.Forms.CheckState.Checked;
            this.check.Location = new System.Drawing.Point(28, 370);
            this.check.Name = "check";
            this.check.Size = new System.Drawing.Size(129, 19);
            this.check.TabIndex = 51;
            this.check.Text = "수신 거부 제외";
            this.check.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(113, 341);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(30, 15);
            this.label27.TabIndex = 39;
            this.label27.Text = "0명";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(25, 341);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(67, 15);
            this.label26.TabIndex = 38;
            this.label26.Text = "받는사람";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(28, 401);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(191, 30);
            this.button16.TabIndex = 35;
            this.button16.Text = "해당고객 선호서비스 삽입";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.Button16_Click);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(23, 40);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(332, 278);
            this.textBox14.TabIndex = 2;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(20, 11);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(37, 15);
            this.label23.TabIndex = 33;
            this.label23.Text = "문자";
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(299, 455);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 31;
            this.button17.Text = "보내기";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.Button17_Click);
            // 
            // joinpanel
            // 
            this.joinpanel.Controls.Add(this.listView1);
            this.joinpanel.Controls.Add(this.panel1);
            this.joinpanel.Controls.Add(this.panel4);
            this.joinpanel.Controls.Add(this.panel10);
            this.joinpanel.Controls.Add(this.panel9);
            this.joinpanel.Controls.Add(this.panel8);
            this.joinpanel.Controls.Add(this.panel3);
            this.joinpanel.Location = new System.Drawing.Point(12, 94);
            this.joinpanel.Name = "joinpanel";
            this.joinpanel.Size = new System.Drawing.Size(1208, 672);
            this.joinpanel.TabIndex = 12;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Control;
            this.panel5.Controls.Add(this.button32);
            this.panel5.Controls.Add(this.button31);
            this.panel5.Controls.Add(this.button30);
            this.panel5.Location = new System.Drawing.Point(1226, 94);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(176, 498);
            this.panel5.TabIndex = 13;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.SystemColors.Control;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Font = new System.Drawing.Font("굴림", 9F);
            this.button32.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button32.Location = new System.Drawing.Point(1, 104);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(174, 45);
            this.button32.TabIndex = 3;
            this.button32.Text = "매출 삭제";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.SystemColors.Control;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Font = new System.Drawing.Font("굴림", 9F);
            this.button31.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button31.Location = new System.Drawing.Point(1, 53);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(174, 45);
            this.button31.TabIndex = 2;
            this.button31.Text = "매출 수정";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.SystemColors.Control;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Font = new System.Drawing.Font("굴림", 9F);
            this.button30.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button30.Location = new System.Drawing.Point(1, 2);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(174, 45);
            this.button30.TabIndex = 1;
            this.button30.Text = "매출 추가";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // sellpanel
            // 
            this.sellpanel.Controls.Add(this.listView3);
            this.sellpanel.Controls.Add(this.panel19);
            this.sellpanel.Controls.Add(this.panel21);
            this.sellpanel.Controls.Add(this.panel20);
            this.sellpanel.Location = new System.Drawing.Point(12, 94);
            this.sellpanel.Name = "sellpanel";
            this.sellpanel.Size = new System.Drawing.Size(1208, 674);
            this.sellpanel.TabIndex = 14;
            // 
            // listView3
            // 
            this.listView3.Location = new System.Drawing.Point(0, 0);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(820, 674);
            this.listView3.TabIndex = 15;
            this.listView3.UseCompatibleStateImageBehavior = false;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.SystemColors.Control;
            this.panel19.Controls.Add(this.textBox29);
            this.panel19.Controls.Add(this.label84);
            this.panel19.Controls.Add(this.textBox39);
            this.panel19.Controls.Add(this.label85);
            this.panel19.Controls.Add(this.textBox40);
            this.panel19.Controls.Add(this.dateTimePicker3);
            this.panel19.Controls.Add(this.label53);
            this.panel19.Controls.Add(this.textBox27);
            this.panel19.Controls.Add(this.textBox28);
            this.panel19.Controls.Add(this.label54);
            this.panel19.Controls.Add(this.label56);
            this.panel19.Controls.Add(this.label57);
            this.panel19.Controls.Add(this.label58);
            this.panel19.Controls.Add(this.button33);
            this.panel19.Location = new System.Drawing.Point(821, 4);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(384, 492);
            this.panel19.TabIndex = 57;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(270, 121);
            this.textBox29.MaxLength = 4;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(56, 25);
            this.textBox29.TabIndex = 5;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(253, 126);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(15, 15);
            this.label84.TabIndex = 54;
            this.label84.Text = "-";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(195, 121);
            this.textBox39.MaxLength = 4;
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(56, 25);
            this.textBox39.TabIndex = 4;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(181, 126);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(15, 15);
            this.label85.TabIndex = 52;
            this.label85.Text = "-";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(136, 121);
            this.textBox40.MaxLength = 3;
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(43, 25);
            this.textBox40.TabIndex = 3;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Cursor = System.Windows.Forms.Cursors.Default;
            this.dateTimePicker3.CustomFormat = "MM월dd일 ddd요일 HH:mm";
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker3.Location = new System.Drawing.Point(136, 45);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(200, 25);
            this.dateTimePicker3.TabIndex = 1;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(43, 163);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(37, 15);
            this.label53.TabIndex = 39;
            this.label53.Text = "가격";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(136, 158);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 25);
            this.textBox27.TabIndex = 6;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(136, 83);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(197, 25);
            this.textBox28.TabIndex = 2;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(43, 88);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(52, 15);
            this.label54.TabIndex = 36;
            this.label54.Text = "서비스";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(43, 126);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(52, 15);
            this.label56.TabIndex = 35;
            this.label56.Text = "휴대폰";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(43, 50);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(37, 15);
            this.label57.TabIndex = 0;
            this.label57.Text = "날짜";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(20, 11);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(72, 15);
            this.label58.TabIndex = 33;
            this.label58.Text = "매출 추가";
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(299, 446);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(75, 23);
            this.button33.TabIndex = 31;
            this.button33.Text = "추가";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.Button33_Click);
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.SystemColors.Control;
            this.panel21.Controls.Add(this.button48);
            this.panel21.Controls.Add(this.label90);
            this.panel21.Controls.Add(this.label65);
            this.panel21.Controls.Add(this.label67);
            this.panel21.Controls.Add(this.label68);
            this.panel21.Controls.Add(this.button34);
            this.panel21.Location = new System.Drawing.Point(821, 4);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(384, 492);
            this.panel21.TabIndex = 59;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(299, 45);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(75, 23);
            this.button48.TabIndex = 38;
            this.button48.Text = "선택";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.Button48_Click);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(43, 88);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(0, 15);
            this.label90.TabIndex = 37;
            this.label90.Visible = false;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(130, 49);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(30, 15);
            this.label65.TabIndex = 36;
            this.label65.Text = "0개";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(43, 50);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(72, 15);
            this.label67.TabIndex = 0;
            this.label67.Text = "선택 개수";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(20, 11);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(72, 15);
            this.label68.TabIndex = 33;
            this.label68.Text = "매출 삭제";
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(299, 446);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(75, 23);
            this.button34.TabIndex = 31;
            this.button34.Text = "삭제";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.Button34_Click);
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.SystemColors.Control;
            this.panel20.Controls.Add(this.textBox32);
            this.panel20.Controls.Add(this.label88);
            this.panel20.Controls.Add(this.textBox41);
            this.panel20.Controls.Add(this.label89);
            this.panel20.Controls.Add(this.textBox42);
            this.panel20.Controls.Add(this.label87);
            this.panel20.Controls.Add(this.button47);
            this.panel20.Controls.Add(this.label86);
            this.panel20.Controls.Add(this.dateTimePicker5);
            this.panel20.Controls.Add(this.label59);
            this.panel20.Controls.Add(this.textBox30);
            this.panel20.Controls.Add(this.textBox31);
            this.panel20.Controls.Add(this.label60);
            this.panel20.Controls.Add(this.label61);
            this.panel20.Controls.Add(this.label62);
            this.panel20.Controls.Add(this.label63);
            this.panel20.Controls.Add(this.button15);
            this.panel20.Location = new System.Drawing.Point(821, 4);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(384, 492);
            this.panel20.TabIndex = 58;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(268, 177);
            this.textBox32.MaxLength = 4;
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(56, 25);
            this.textBox32.TabIndex = 41;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(251, 182);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(15, 15);
            this.label88.TabIndex = 60;
            this.label88.Text = "-";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(193, 177);
            this.textBox41.MaxLength = 4;
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(56, 25);
            this.textBox41.TabIndex = 40;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(179, 182);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(15, 15);
            this.label89.TabIndex = 58;
            this.label89.Text = "-";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(134, 177);
            this.textBox42.MaxLength = 3;
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(43, 25);
            this.textBox42.TabIndex = 39;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(43, 271);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(0, 15);
            this.label87.TabIndex = 44;
            this.label87.Visible = false;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(299, 61);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(75, 23);
            this.button47.TabIndex = 43;
            this.button47.Text = "선택";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.Button47_Click);
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(41, 65);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(147, 15);
            this.label86.TabIndex = 42;
            this.label86.Text = "매출을 선택해주세요";
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Cursor = System.Windows.Forms.Cursors.Default;
            this.dateTimePicker5.CustomFormat = "yy/MM/dd hh:mm";
            this.dateTimePicker5.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker5.Location = new System.Drawing.Point(134, 102);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(200, 25);
            this.dateTimePicker5.TabIndex = 37;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(41, 219);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(37, 15);
            this.label59.TabIndex = 39;
            this.label59.Text = "가격";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(134, 215);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(100, 25);
            this.textBox30.TabIndex = 42;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(134, 140);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(197, 25);
            this.textBox31.TabIndex = 38;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(41, 145);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(52, 15);
            this.label60.TabIndex = 36;
            this.label60.Text = "서비스";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(41, 182);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(52, 15);
            this.label61.TabIndex = 35;
            this.label61.Text = "휴대폰";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(41, 108);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(37, 15);
            this.label62.TabIndex = 0;
            this.label62.Text = "날짜";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(20, 11);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(72, 15);
            this.label63.TabIndex = 33;
            this.label63.Text = "매출 수정";
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(299, 446);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 31;
            this.button15.Text = "수정";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.Button15_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Control;
            this.panel7.Controls.Add(this.button22);
            this.panel7.Controls.Add(this.button19);
            this.panel7.Controls.Add(this.button18);
            this.panel7.Location = new System.Drawing.Point(1228, 95);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(176, 495);
            this.panel7.TabIndex = 15;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.SystemColors.Control;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("굴림", 9F);
            this.button22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button22.Location = new System.Drawing.Point(0, 103);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(174, 45);
            this.button22.TabIndex = 3;
            this.button22.Text = "사용 제품 제거";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.Control;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("굴림", 9F);
            this.button19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button19.Location = new System.Drawing.Point(0, 1);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(174, 45);
            this.button19.TabIndex = 2;
            this.button19.Text = "사용 제품 수정";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.Control;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("굴림", 9F);
            this.button18.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button18.Location = new System.Drawing.Point(0, 52);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(174, 45);
            this.button18.TabIndex = 1;
            this.button18.Text = "사용 제품 등록";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.listView5);
            this.panel6.Controls.Add(this.panel13);
            this.panel6.Controls.Add(this.panel11);
            this.panel6.Controls.Add(this.panel12);
            this.panel6.Location = new System.Drawing.Point(12, 94);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1208, 674);
            this.panel6.TabIndex = 23;
            // 
            // listView5
            // 
            this.listView5.Location = new System.Drawing.Point(0, 0);
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(820, 674);
            this.listView5.TabIndex = 1;
            this.listView5.UseCompatibleStateImageBehavior = false;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.Control;
            this.panel13.Controls.Add(this.label91);
            this.panel13.Controls.Add(this.button49);
            this.panel13.Controls.Add(this.label66);
            this.panel13.Controls.Add(this.textBox22);
            this.panel13.Controls.Add(this.label39);
            this.panel13.Controls.Add(this.label37);
            this.panel13.Controls.Add(this.textBox21);
            this.panel13.Controls.Add(this.label36);
            this.panel13.Controls.Add(this.button23);
            this.panel13.Location = new System.Drawing.Point(821, 4);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(384, 492);
            this.panel13.TabIndex = 60;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(39, 41);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(0, 15);
            this.label91.TabIndex = 40;
            this.label91.Visible = false;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(299, 64);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(75, 23);
            this.button49.TabIndex = 39;
            this.button49.Text = "선택";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.Button49_Click);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(43, 141);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(37, 15);
            this.label66.TabIndex = 38;
            this.label66.Text = "메모";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(45, 163);
            this.textBox22.Multiline = true;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(282, 136);
            this.textBox22.TabIndex = 37;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(43, 112);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(37, 15);
            this.label39.TabIndex = 36;
            this.label39.Text = "제고";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(41, 68);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(147, 15);
            this.label37.TabIndex = 35;
            this.label37.Text = "제품을 선택해주세요";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(91, 106);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(69, 25);
            this.textBox21.TabIndex = 34;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(20, 11);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(107, 15);
            this.label36.TabIndex = 33;
            this.label36.Text = "사용 제품 수정";
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(299, 446);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 23);
            this.button23.TabIndex = 31;
            this.button23.Text = "저장";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.Button23_Click);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.Control;
            this.panel11.Controls.Add(this.textBox20);
            this.panel11.Controls.Add(this.label35);
            this.panel11.Controls.Add(this.label40);
            this.panel11.Controls.Add(this.textBox23);
            this.panel11.Controls.Add(this.label41);
            this.panel11.Controls.Add(this.button20);
            this.panel11.Location = new System.Drawing.Point(821, 4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(384, 492);
            this.panel11.TabIndex = 58;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(139, 89);
            this.textBox20.Multiline = true;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(208, 166);
            this.textBox20.TabIndex = 36;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(41, 89);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(37, 15);
            this.label35.TabIndex = 35;
            this.label35.Text = "비고";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(41, 56);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(72, 15);
            this.label40.TabIndex = 0;
            this.label40.Text = "상품 이름";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(139, 53);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(208, 25);
            this.textBox23.TabIndex = 34;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(20, 11);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(107, 15);
            this.label41.TabIndex = 33;
            this.label41.Text = "사용 제품 등록";
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(299, 446);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 23);
            this.button20.TabIndex = 31;
            this.button20.Text = "등록";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.Button20_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.Control;
            this.panel12.Controls.Add(this.button50);
            this.panel12.Controls.Add(this.label93);
            this.panel12.Controls.Add(this.label16);
            this.panel12.Controls.Add(this.label15);
            this.panel12.Controls.Add(this.label38);
            this.panel12.Controls.Add(this.button21);
            this.panel12.Location = new System.Drawing.Point(821, 4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(384, 492);
            this.panel12.TabIndex = 59;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(299, 52);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(75, 23);
            this.button50.TabIndex = 38;
            this.button50.Text = "선택";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.Button50_Click);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(77, 97);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(0, 15);
            this.label93.TabIndex = 37;
            this.label93.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(157, 56);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(30, 15);
            this.label16.TabIndex = 35;
            this.label16.Text = "0개";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(41, 56);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(92, 15);
            this.label15.TabIndex = 34;
            this.label15.Text = "선택 제품 수";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(20, 11);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(107, 15);
            this.label38.TabIndex = 33;
            this.label38.Text = "사용 제품 제거";
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(299, 446);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 23);
            this.button21.TabIndex = 31;
            this.button21.Text = "제거";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.Button21_Click);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.listView4);
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Controls.Add(this.panel17);
            this.panel14.Controls.Add(this.panel18);
            this.panel14.Location = new System.Drawing.Point(12, 94);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(1208, 674);
            this.panel14.TabIndex = 24;
            // 
            // listView4
            // 
            this.listView4.Location = new System.Drawing.Point(0, 0);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(820, 674);
            this.listView4.TabIndex = 1;
            this.listView4.UseCompatibleStateImageBehavior = false;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.Control;
            this.panel15.Controls.Add(this.label95);
            this.panel15.Controls.Add(this.label42);
            this.panel15.Controls.Add(this.textBox12);
            this.panel15.Controls.Add(this.textBox11);
            this.panel15.Controls.Add(this.textBox10);
            this.panel15.Controls.Add(this.label20);
            this.panel15.Controls.Add(this.label19);
            this.panel15.Controls.Add(this.label45);
            this.panel15.Controls.Add(this.textBox13);
            this.panel15.Controls.Add(this.label46);
            this.panel15.Controls.Add(this.button24);
            this.panel15.Location = new System.Drawing.Point(821, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(384, 492);
            this.panel15.TabIndex = 56;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label95.Location = new System.Drawing.Point(43, 203);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(0, 15);
            this.label95.TabIndex = 41;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(43, 164);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(37, 15);
            this.label42.TabIndex = 39;
            this.label42.Text = "직급";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(138, 159);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(186, 25);
            this.textBox12.TabIndex = 40;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(138, 121);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(186, 25);
            this.textBox11.TabIndex = 38;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(138, 83);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(186, 25);
            this.textBox10.TabIndex = 37;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(42, 126);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(67, 15);
            this.label20.TabIndex = 36;
            this.label20.Text = "비밀번호";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(42, 88);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 15);
            this.label19.TabIndex = 35;
            this.label19.Text = "아이디";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(42, 50);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(37, 15);
            this.label45.TabIndex = 0;
            this.label45.Text = "이름";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(138, 45);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(186, 25);
            this.textBox13.TabIndex = 34;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(20, 11);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(87, 15);
            this.label46.TabIndex = 33;
            this.label46.Text = "사용자 등록";
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(299, 446);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 23);
            this.button24.TabIndex = 31;
            this.button24.Text = "등록";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.Button24_Click);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.SystemColors.Control;
            this.panel17.Controls.Add(this.button52);
            this.panel17.Controls.Add(this.label50);
            this.panel17.Controls.Add(this.label43);
            this.panel17.Controls.Add(this.textBox24);
            this.panel17.Controls.Add(this.textBox25);
            this.panel17.Controls.Add(this.textBox26);
            this.panel17.Controls.Add(this.label44);
            this.panel17.Controls.Add(this.label47);
            this.panel17.Controls.Add(this.label48);
            this.panel17.Controls.Add(this.label49);
            this.panel17.Controls.Add(this.button28);
            this.panel17.Location = new System.Drawing.Point(821, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(384, 492);
            this.panel17.TabIndex = 57;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(299, 46);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(75, 23);
            this.button52.TabIndex = 43;
            this.button52.Text = "선택";
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.Button52_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(138, 50);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(97, 15);
            this.label50.TabIndex = 41;
            this.label50.Text = "선택해주세요";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(43, 164);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(37, 15);
            this.label43.TabIndex = 39;
            this.label43.Text = "직급";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(138, 159);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(186, 25);
            this.textBox24.TabIndex = 40;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(138, 121);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(186, 25);
            this.textBox25.TabIndex = 38;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(138, 83);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(186, 25);
            this.textBox26.TabIndex = 37;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(42, 126);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(67, 15);
            this.label44.TabIndex = 36;
            this.label44.Text = "비밀번호";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(42, 88);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(37, 15);
            this.label47.TabIndex = 35;
            this.label47.Text = "이름";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(42, 50);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(52, 15);
            this.label48.TabIndex = 0;
            this.label48.Text = "아이디";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(20, 11);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(87, 15);
            this.label49.TabIndex = 33;
            this.label49.Text = "사용자 수정";
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(299, 446);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 23);
            this.button28.TabIndex = 31;
            this.button28.Text = "수정";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.Button28_Click);
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.SystemColors.Control;
            this.panel18.Controls.Add(this.label94);
            this.panel18.Controls.Add(this.button51);
            this.panel18.Controls.Add(this.label52);
            this.panel18.Controls.Add(this.label51);
            this.panel18.Controls.Add(this.label55);
            this.panel18.Controls.Add(this.button29);
            this.panel18.Location = new System.Drawing.Point(821, 3);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(384, 492);
            this.panel18.TabIndex = 57;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(152, 86);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(0, 15);
            this.label94.TabIndex = 37;
            this.label94.Visible = false;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(299, 46);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(75, 23);
            this.button51.TabIndex = 36;
            this.button51.Text = "선택";
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.Button51_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(152, 50);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(30, 15);
            this.label52.TabIndex = 35;
            this.label52.Text = "0명";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(42, 50);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(87, 15);
            this.label51.TabIndex = 34;
            this.label51.Text = "선택 사용자";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(20, 11);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(87, 15);
            this.label55.TabIndex = 33;
            this.label55.Text = "사용자 삭제";
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(299, 446);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(75, 23);
            this.button29.TabIndex = 31;
            this.button29.Text = "삭제";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.Button29_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.Control;
            this.panel16.Controls.Add(this.button25);
            this.panel16.Controls.Add(this.button26);
            this.panel16.Controls.Add(this.button27);
            this.panel16.Location = new System.Drawing.Point(1228, 94);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(176, 495);
            this.panel16.TabIndex = 25;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.SystemColors.Control;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Font = new System.Drawing.Font("굴림", 9F);
            this.button25.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button25.Location = new System.Drawing.Point(1, 104);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(174, 45);
            this.button25.TabIndex = 23;
            this.button25.Text = "사용자 삭제";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.SystemColors.Control;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Font = new System.Drawing.Font("굴림", 9F);
            this.button26.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button26.Location = new System.Drawing.Point(1, 53);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(174, 45);
            this.button26.TabIndex = 22;
            this.button26.Text = "사용자 수정";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.SystemColors.Control;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Font = new System.Drawing.Font("굴림", 9F);
            this.button27.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button27.Location = new System.Drawing.Point(1, 2);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(174, 45);
            this.button27.TabIndex = 21;
            this.button27.Text = "사용자 등록";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.SystemColors.Control;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Font = new System.Drawing.Font("굴림", 9F);
            this.button35.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button35.Location = new System.Drawing.Point(290, 12);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(90, 80);
            this.button35.TabIndex = 26;
            this.button35.Text = "예약";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.SystemColors.Control;
            this.panel22.Controls.Add(this.button43);
            this.panel22.Controls.Add(this.button36);
            this.panel22.Controls.Add(this.button38);
            this.panel22.Location = new System.Drawing.Point(1228, 94);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(176, 495);
            this.panel22.TabIndex = 8;
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.SystemColors.Control;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Font = new System.Drawing.Font("굴림", 9F);
            this.button43.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button43.Location = new System.Drawing.Point(0, 105);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(174, 45);
            this.button43.TabIndex = 8;
            this.button43.Text = "매출 전환";
            this.button43.UseVisualStyleBackColor = false;
            this.button43.Click += new System.EventHandler(this.Button43_Click);
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.SystemColors.Control;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Font = new System.Drawing.Font("굴림", 9F);
            this.button36.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button36.Location = new System.Drawing.Point(0, 54);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(174, 45);
            this.button36.TabIndex = 7;
            this.button36.Text = "예약 제거";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.SystemColors.Control;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Font = new System.Drawing.Font("굴림", 9F);
            this.button38.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button38.Location = new System.Drawing.Point(0, 3);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(174, 45);
            this.button38.TabIndex = 1;
            this.button38.Text = "예약 추가";
            this.button38.UseVisualStyleBackColor = false;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.listView6);
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Controls.Add(this.panel25);
            this.panel23.Controls.Add(this.panel2);
            this.panel23.Location = new System.Drawing.Point(12, 94);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(1208, 672);
            this.panel23.TabIndex = 62;
            // 
            // listView6
            // 
            this.listView6.Location = new System.Drawing.Point(0, 0);
            this.listView6.Name = "listView6";
            this.listView6.Size = new System.Drawing.Size(820, 674);
            this.listView6.TabIndex = 0;
            this.listView6.UseCompatibleStateImageBehavior = false;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.SystemColors.Control;
            this.panel24.Controls.Add(this.textBox36);
            this.panel24.Controls.Add(this.label79);
            this.panel24.Controls.Add(this.textBox37);
            this.panel24.Controls.Add(this.label82);
            this.panel24.Controls.Add(this.textBox38);
            this.panel24.Controls.Add(this.textBox35);
            this.panel24.Controls.Add(this.label78);
            this.panel24.Controls.Add(this.textBox33);
            this.panel24.Controls.Add(this.label64);
            this.panel24.Controls.Add(this.dateTimePicker6);
            this.panel24.Controls.Add(this.label70);
            this.panel24.Controls.Add(this.label71);
            this.panel24.Controls.Add(this.label72);
            this.panel24.Controls.Add(this.button37);
            this.panel24.Location = new System.Drawing.Point(821, 4);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(384, 492);
            this.panel24.TabIndex = 49;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(272, 49);
            this.textBox36.MaxLength = 4;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(56, 25);
            this.textBox36.TabIndex = 48;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(255, 54);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(15, 15);
            this.label79.TabIndex = 49;
            this.label79.Text = "-";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(197, 49);
            this.textBox37.MaxLength = 4;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(56, 25);
            this.textBox37.TabIndex = 46;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(183, 54);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(15, 15);
            this.label82.TabIndex = 47;
            this.label82.Text = "-";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(138, 49);
            this.textBox38.MaxLength = 3;
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(43, 25);
            this.textBox38.TabIndex = 45;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(138, 157);
            this.textBox35.Multiline = true;
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(217, 211);
            this.textBox35.TabIndex = 42;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(43, 157);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(37, 15);
            this.label78.TabIndex = 41;
            this.label78.Text = "비고";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(139, 117);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(120, 25);
            this.textBox33.TabIndex = 40;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(42, 122);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(52, 15);
            this.label64.TabIndex = 39;
            this.label64.Text = "서비스";
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.CustomFormat = "yy년 MM월 dd일 HH시 mm분";
            this.dateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker6.Location = new System.Drawing.Point(138, 82);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(220, 25);
            this.dateTimePicker6.TabIndex = 38;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(42, 87);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(72, 15);
            this.label70.TabIndex = 36;
            this.label70.Text = "예약 시간";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(42, 52);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(52, 15);
            this.label71.TabIndex = 0;
            this.label71.Text = "휴대폰";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(20, 11);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(37, 15);
            this.label72.TabIndex = 33;
            this.label72.Text = "예약";
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(299, 445);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(75, 23);
            this.button37.TabIndex = 31;
            this.button37.Text = "추가";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.Button37_Click);
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.SystemColors.Control;
            this.panel25.Controls.Add(this.ids3);
            this.panel25.Controls.Add(this.button46);
            this.panel25.Controls.Add(this.label69);
            this.panel25.Controls.Add(this.label73);
            this.panel25.Controls.Add(this.label74);
            this.panel25.Controls.Add(this.button40);
            this.panel25.Location = new System.Drawing.Point(821, 4);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(384, 492);
            this.panel25.TabIndex = 50;
            // 
            // ids3
            // 
            this.ids3.AutoSize = true;
            this.ids3.Location = new System.Drawing.Point(42, 73);
            this.ids3.Name = "ids3";
            this.ids3.Size = new System.Drawing.Size(0, 15);
            this.ids3.TabIndex = 38;
            this.ids3.Visible = false;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(299, 45);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(75, 23);
            this.button46.TabIndex = 37;
            this.button46.Text = "선택";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.Button46_Click);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(130, 49);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(30, 15);
            this.label69.TabIndex = 36;
            this.label69.Text = "0개";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(42, 50);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(37, 15);
            this.label73.TabIndex = 0;
            this.label73.Text = "선택";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(20, 11);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(37, 15);
            this.label74.TabIndex = 33;
            this.label74.Text = "제거";
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(299, 445);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(75, 23);
            this.button40.TabIndex = 31;
            this.button40.Text = "제거";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.Button40_Click_1);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.label83);
            this.panel2.Controls.Add(this.button45);
            this.panel2.Controls.Add(this.label80);
            this.panel2.Controls.Add(this.label81);
            this.panel2.Controls.Add(this.button44);
            this.panel2.Location = new System.Drawing.Point(821, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(384, 492);
            this.panel2.TabIndex = 50;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(42, 89);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(0, 15);
            this.label83.TabIndex = 35;
            this.label83.Visible = false;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(299, 47);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(75, 23);
            this.button45.TabIndex = 34;
            this.button45.Text = "선택";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.Button45_Click);
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(42, 50);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(187, 15);
            this.label80.TabIndex = 0;
            this.label80.Text = "예약 정보를 선택해 주세요";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(20, 11);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(72, 15);
            this.label81.TabIndex = 33;
            this.label81.Text = "매출 전환";
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(299, 445);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(75, 23);
            this.button44.TabIndex = 31;
            this.button44.Text = "전환";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.Button44_Click);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(1074, 45);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(0, 15);
            this.label92.TabIndex = 41;
            // 
            // ids
            // 
            this.ids.AutoSize = true;
            this.ids.Location = new System.Drawing.Point(49, 356);
            this.ids.Name = "ids";
            this.ids.Size = new System.Drawing.Size(0, 15);
            this.ids.TabIndex = 68;
            this.ids.Visible = false;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(55, 356);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(0, 15);
            this.label96.TabIndex = 70;
            this.label96.Visible = false;
            // 
            // _2_MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1405, 774);
            this.Controls.Add(this.label92);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.phone);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.joinpanel);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.sellpanel);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel23);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "_2_MainForm";
            this.Text = "미용실 관리";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Closing);
            this.Load += new System.EventHandler(this._2_MainForm_Load);
            this.phone.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.joinpanel.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.sellpanel.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel phone;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Panel joinpanel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel sellpanel;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ListView listView5;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.ListView listView6;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label msg;
        private System.Windows.Forms.CheckBox check;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Label ids2;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Label ids3;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label ids;
    }
}